import { Location } from './types/ausPostcodes';
export declare const findLocationsByPostcode: (postcode: string) => Location[];
//# sourceMappingURL=postcodes.d.ts.map