export interface Location {
    id: number;
    postcode: string;
    locality: string;
    state: string;
}
//# sourceMappingURL=ausPostcodes.d.ts.map