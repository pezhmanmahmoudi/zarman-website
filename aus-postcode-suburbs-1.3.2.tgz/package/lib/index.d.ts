export * from './postcodes';
//# sourceMappingURL=index.d.ts.map